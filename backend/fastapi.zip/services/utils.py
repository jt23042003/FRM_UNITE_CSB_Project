# Misc utility functions go here
