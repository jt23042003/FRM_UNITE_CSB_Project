# AnomalyDetector class goes here
