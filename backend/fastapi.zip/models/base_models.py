# Pydantic models go here
