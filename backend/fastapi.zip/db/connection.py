import psycopg2
from config import conn_params

def get_db_connection():
    return psycopg2.connect(**conn_params)
