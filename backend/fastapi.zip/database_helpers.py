# Additional DB helper functions go here
