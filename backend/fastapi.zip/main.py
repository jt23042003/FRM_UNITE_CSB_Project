# Entry point for FastAPI app
