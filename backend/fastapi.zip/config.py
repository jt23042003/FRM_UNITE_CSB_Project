conn_params = {
    'host': '34.47.219.225',
    'dbname': 'unitedb',
    'user': 'unitedb_user',
    'password': 'password123',
    'port': '5432'
}
